import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
//
//       Reader reader = new Reader("кандыбек",24,"asdf",2345,12345234);
//        System.out.println(reader.takeBook(3));
//        System.out.println(reader.returnBook(3));
//
//
//         Person person1 = new Person(" aa ",12345, " aa ");
//         Person person2 = new Person(" aa ",12, " aa ");
//         Person person3 = new Person(" aa ",123, " aa ");
//         Person person5 = new Person(" aa ",123345, " aa ");
//         Person person6 = new Person(" aa ",1, " aa ");
//        Person [] person4 = {person1,person2,person3,person5,person6};
//         System.out.println(aa(person4));
//        System.out.println(gg(person4));

//    public static Person aa (Person [] person4 ){
//        Person ss = person4 [0];
//        for (int i = 0 ; i < person4.length; i++) {
//            if  (person4[i].age< ss.age){
//                ss = person4 [i];
//            }
//        }
//        return ss;
//    }
//    public static Person gg (Person [] person4 ){
//        Person ss = person4 [0];
//        for (int i = 0 ; i < person4.length; i++) {
//            if  (person4[i].age> ss.age){
//                ss = person4 [i];
//            }
//        }
//        return ss;
//    }

        Гул гул1 = new Гул(" роза ", 5, 1500);
        Гул гул2 = new Гул(" кактус ", 3, 150);
        Гул гул3 = new Гул(" роза ", 7, 1700);
        Гул гул4 = new Гул(" рамашка ", 10, 2000);
        Гул гул5 = new Гул(" тюльпан ", 6, 1400);
        Гул[] aa = {гул1, гул2, гул3, гул4, гул5};
        System.out.println(ss(aa));
    }

    public static Гул ss(Гул[] aa) {
        Гул ss = aa[0];
        for (int i = 0; i < aa.length ; i++) {
            if (aa[i].цена > ss.цена ) {
                ss = aa[i];
            }

        }
        return ss;
    }
}